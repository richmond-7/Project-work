import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Clock, MessageCircle, Users, AlertCircle, Settings, Download } from "lucide-react";
import NotificationsTab from "@/pages/dashboard/NotificationsTab";
import RemindersTab from "@/pages/dashboard/RemindersTab";
import ChatbotTab from "@/pages/dashboard/ChatbotTab";
import CommunityTab from "@/pages/dashboard/CommunityTab";
import ProfileTab from "@/pages/dashboard/ProfileTab";
import EmergencyTab from "@/pages/dashboard/EmergencyTab";
import ExportTab from "@/pages/dashboard/ExportTab";

export default function Dashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("notifications");

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gradient">Health Dashboard</h1>
            <p className="text-muted-foreground mt-1">Welcome back, {user?.name || "User"}</p>
          </div>
          <Button className="btn-accent" size="lg">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="card-elevated p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Notifications</p>
                <p className="text-2xl font-bold mt-1">3</p>
              </div>
              <Bell className="w-8 h-8 text-accent opacity-30" />
            </div>
          </Card>
          <Card className="card-elevated p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Reminders</p>
                <p className="text-2xl font-bold mt-1">2</p>
              </div>
              <Clock className="w-8 h-8 text-accent opacity-30" />
            </div>
          </Card>
          <Card className="card-elevated p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Messages</p>
                <p className="text-2xl font-bold mt-1">5</p>
              </div>
              <MessageCircle className="w-8 h-8 text-accent opacity-30" />
            </div>
          </Card>
          <Card className="card-elevated p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Community</p>
                <p className="text-2xl font-bold mt-1">12</p>
              </div>
              <Users className="w-8 h-8 text-accent opacity-30" />
            </div>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Card className="card-elevated">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-4">
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="reminders" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Reminders
              </TabsTrigger>
              <TabsTrigger value="chatbot" className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                Chatbot
              </TabsTrigger>
              <TabsTrigger value="community" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Community
              </TabsTrigger>
              <TabsTrigger value="emergency" className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Emergency
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="export" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                Export & Share
              </TabsTrigger>
            </TabsList>

            <div className="p-6">
              <TabsContent value="notifications" className="mt-0">
                <NotificationsTab />
              </TabsContent>
              <TabsContent value="reminders" className="mt-0">
                <RemindersTab />
              </TabsContent>
              <TabsContent value="chatbot" className="mt-0">
                <ChatbotTab />
              </TabsContent>
              <TabsContent value="community" className="mt-0">
                <CommunityTab />
              </TabsContent>
              <TabsContent value="emergency" className="mt-0">
                <EmergencyTab />
              </TabsContent>
              <TabsContent value="profile" className="mt-0">
                <ProfileTab />
              </TabsContent>
              <TabsContent value="export" className="mt-0">
                <ExportTab />
              </TabsContent>
            </div>
          </Tabs>
        </Card>
      </div>
    </DashboardLayout>
  );
}
