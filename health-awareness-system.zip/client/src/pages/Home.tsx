import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Clock, Users, MessageCircle, AlertCircle, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (isAuthenticated) {
    navigate("/dashboard");
    return null;
  }

  const features = [
    {
      icon: Heart,
      title: "Personalized Health Tips",
      description: "Receive daily health notifications tailored to your specific health conditions",
    },
    {
      icon: Clock,
      title: "Smart Reminders",
      description: "Never miss medication or appointments with customizable reminders",
    },
    {
      icon: MessageCircle,
      title: "AI Health Assistant",
      description: "Chat with our intelligent health assistant for quick guidance",
    },
    {
      icon: Users,
      title: "Community Support",
      description: "Connect with others, share experiences, and learn from peer support",
    },
    {
      icon: AlertCircle,
      title: "Emergency Alerts",
      description: "Quickly notify health volunteers and clinics in urgent situations",
    },
    {
      icon: Zap,
      title: "Health Profile",
      description: "Manage your medical history, allergies, and emergency contacts",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-accent" />
            <span className="text-xl font-bold text-gradient">HealthAware</span>
          </div>
          <Button onClick={() => window.location.href = getLoginUrl()} className="btn-accent">
            Sign In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold leading-tight">
            Your <span className="text-gradient">Health Companion</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Take control of your health with personalized notifications, smart reminders, AI assistance, and community support. Stay informed, stay healthy.
          </p>
          <div className="flex gap-4 justify-center pt-4">
            <Button onClick={() => window.location.href = getLoginUrl()} size="lg" className="btn-accent">
              Get Started Free
            </Button>
            <Button size="lg" variant="outline">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container py-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Everything You Need for Better Health
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <Card key={idx} className="card-elevated p-6 hover:shadow-xl transition-all duration-300">
                  <Icon className="w-8 h-8 text-accent mb-4" />
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container py-20">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold">
                Manage Your Health with <span className="text-gradient">Confidence</span>
              </h2>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                    <span className="text-accent font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Personalized Care</h3>
                    <p className="text-sm text-muted-foreground">Health tips tailored to your specific conditions</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                    <span className="text-accent font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Never Forget</h3>
                    <p className="text-sm text-muted-foreground">Smart reminders for medications and appointments</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                    <span className="text-accent font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">24/7 Support</h3>
                    <p className="text-sm text-muted-foreground">AI assistant and community available anytime</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                    <span className="text-accent font-bold">✓</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Emergency Ready</h3>
                    <p className="text-sm text-muted-foreground">Quick access to emergency alerts and contacts</p>
                  </div>
                </div>
              </div>
            </div>
            <Card className="card-elevated p-8 text-center">
              <div className="space-y-4">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
                  <Heart className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold">Your Health Matters</h3>
                <p className="text-muted-foreground">Join thousands of users who are taking control of their health journey</p>
                <Button onClick={() => window.location.href = getLoginUrl()} className="btn-accent w-full">
                  Start Your Journey
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20">
        <Card className="card-elevated p-12 text-center bg-gradient-to-r from-accent/10 to-secondary/10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Take Control?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join our health-conscious community and start receiving personalized health guidance today.
          </p>
          <Button onClick={() => window.location.href = getLoginUrl()} size="lg" className="btn-accent">
            Sign Up Now - It's Free
          </Button>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 mt-20">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; 2026 HealthAware. Your personal health companion.</p>
        </div>
      </footer>
    </div>
  );
}
