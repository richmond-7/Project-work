import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { nanoid } from "nanoid";

export default function ChatbotTab() {
  const [conversationId] = useState(() => nanoid());
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sendMessageMutation = trpc.health.sendChatMessage.useMutation();
  const escalateMutation = trpc.health.escalateChat.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);

    try {
      const response = await sendMessageMutation.mutateAsync({
        conversationId,
        message: userMessage,
      });
      setMessages((prev) => [...prev, { role: "bot", content: response.response }]);
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  const handleEscalate = async () => {
    try {
      await escalateMutation.mutateAsync({
        conversationId,
        reason: "User requested human support",
      });
      toast.success("Your request has been escalated to a human operator");
    } catch (error) {
      toast.error("Failed to escalate");
    }
  };

  return (
    <div className="space-y-4 h-[600px] flex flex-col">
      <h2 className="text-xl font-semibold">Health Assistant</h2>

      {/* Chat Messages */}
      <Card className="card-elevated flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <MessageCircle className="w-12 h-12 text-muted-foreground/30 mb-3" />
              <p className="text-muted-foreground">Start a conversation with our health assistant</p>
              <p className="text-xs text-muted-foreground mt-2">Ask about medications, appointments, diet, exercise, or general health</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    msg.role === "user"
                      ? "bg-accent text-accent-foreground rounded-br-none"
                      : "bg-muted text-muted-foreground rounded-bl-none"
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </Card>

      {/* Input Area */}
      <div className="space-y-2">
        <div className="flex gap-2">
          <Input
            placeholder="Ask me anything about your health..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            disabled={sendMessageMutation.isPending}
          />
          <Button onClick={handleSendMessage} disabled={sendMessageMutation.isPending} className="btn-accent">
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <Button
          onClick={handleEscalate}
          variant="outline"
          className="w-full"
          disabled={escalateMutation.isPending}
        >
          <AlertTriangle className="w-4 h-4 mr-2" />
          Escalate to Human Support
        </Button>
      </div>
    </div>
  );
}
