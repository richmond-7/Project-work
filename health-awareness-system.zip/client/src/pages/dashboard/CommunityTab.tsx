import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Users, Plus, Heart, MessageSquare } from "lucide-react";
import { toast } from "sonner";

export default function CommunityTab() {
  const { data: posts, isLoading } = trpc.community.getPosts.useQuery({ limit: 20 });
  const createPostMutation = trpc.community.createPost.useMutation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "experiences" as const,
  });

  const handleCreatePost = async () => {
    if (!formData.title || !formData.content) {
      toast.error("Please fill in all fields");
      return;
    }

    try {
      await createPostMutation.mutateAsync(formData);
      toast.success("Post created successfully!");
      setFormData({ title: "", content: "", category: "experiences" });
      setShowForm(false);
    } catch (error) {
      toast.error("Failed to create post");
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading community posts...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Community Support</h2>
        <Button onClick={() => setShowForm(!showForm)} className="btn-accent">
          <Plus className="w-4 h-4 mr-2" />
          New Post
        </Button>
      </div>

      {showForm && (
        <Card className="card-elevated p-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <Input
                placeholder="Share your experience or ask a question"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Content</label>
              <textarea
                className="input-field min-h-24"
                placeholder="Tell us more about your experience..."
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreatePost} disabled={createPostMutation.isPending} className="btn-accent">
                Post
              </Button>
              <Button onClick={() => setShowForm(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      {posts && posts.length > 0 ? (
        <div className="space-y-3">
          {posts.map((post) => (
            <Card key={post.id} className="card-elevated p-4">
              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold text-lg">{post.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{post.content}</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <span className="inline-block px-2 py-1 bg-accent/10 text-accent text-xs rounded capitalize">
                    {post.category}
                  </span>
                </div>
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <button className="flex items-center gap-1 hover:text-accent transition-colors">
                    <Heart className="w-4 h-4" />
                    {post.likes} Likes
                  </button>
                  <button className="flex items-center gap-1 hover:text-accent transition-colors">
                    <MessageSquare className="w-4 h-4" />
                    {post.replies} Replies
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-elevated p-8 text-center">
          <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No posts yet. Be the first to share your experience!</p>
        </Card>
      )}
    </div>
  );
}
