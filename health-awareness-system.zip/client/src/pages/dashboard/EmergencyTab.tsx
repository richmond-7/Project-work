import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, AlertTriangle, AlertOctagon } from "lucide-react";
import { toast } from "sonner";

export default function EmergencyTab() {
  const { data: alerts, isLoading } = trpc.health.getEmergencyAlerts.useQuery();
  const createAlertMutation = trpc.health.createEmergencyAlert.useMutation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    severity: "medium" as const,
    description: "",
    location: "",
  });

  const handleCreateAlert = async () => {
    if (!formData.description) {
      toast.error("Please describe the emergency");
      return;
    }

    try {
      await createAlertMutation.mutateAsync(formData);
      toast.success("Emergency alert sent to nearby health volunteers!");
      setFormData({ severity: "medium", description: "", location: "" });
      setShowForm(false);
    } catch (error) {
      toast.error("Failed to send emergency alert");
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertOctagon className="w-5 h-5 text-destructive" />;
      case "high":
        return <AlertTriangle className="w-5 h-5 text-orange-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading emergency alerts...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Emergency Alerts</h2>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-destructive hover:bg-destructive/90 text-white"
        >
          <AlertCircle className="w-4 h-4 mr-2" />
          Send Emergency Alert
        </Button>
      </div>

      {showForm && (
        <Card className="card-elevated p-6 border-destructive/30 bg-destructive/5">
          <div className="space-y-4">
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-sm text-destructive">
              <p className="font-semibold mb-1">Emergency Alert</p>
              <p>This will notify nearby health volunteers and clinics of your emergency situation.</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Severity Level</label>
              <Select value={formData.severity} onValueChange={(value: any) => setFormData({ ...formData, severity: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low - Minor health concern</SelectItem>
                  <SelectItem value="medium">Medium - Moderate concern</SelectItem>
                  <SelectItem value="high">High - Serious situation</SelectItem>
                  <SelectItem value="critical">Critical - Life-threatening</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea
                className="input-field min-h-24"
                placeholder="Describe your emergency situation..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Location (Optional)</label>
              <Input
                placeholder="Your current location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleCreateAlert}
                disabled={createAlertMutation.isPending}
                className="bg-destructive hover:bg-destructive/90 text-white"
              >
                Send Alert
              </Button>
              <Button onClick={() => setShowForm(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      {alerts && alerts.length > 0 ? (
        <div className="space-y-3">
          {alerts.map((alert) => (
            <Card key={alert.id} className="card-elevated p-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0 mt-1">{getSeverityIcon(alert.severity)}</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold capitalize">{alert.severity} Severity Alert</h3>
                      <p className="text-sm text-muted-foreground mt-1">{alert.description}</p>
                      {alert.location && (
                        <p className="text-sm text-muted-foreground">Location: {alert.location}</p>
                      )}
                      <div className="flex gap-2 mt-2">
                        <span
                          className={`inline-block px-2 py-1 text-xs rounded capitalize ${
                            alert.status === "resolved"
                              ? "bg-accent/10 text-accent"
                              : alert.status === "acknowledged"
                              ? "bg-secondary/10 text-secondary"
                              : "bg-orange-500/10 text-orange-500"
                          }`}
                        >
                          {alert.status}
                        </span>
                      </div>
                      {alert.respondedBy && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Responded by: {alert.respondedBy}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-elevated p-8 text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No emergency alerts yet. Stay safe!</p>
        </Card>
      )}
    </div>
  );
}
