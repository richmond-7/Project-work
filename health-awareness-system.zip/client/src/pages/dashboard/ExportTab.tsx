import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Share2, Plus, Trash2, FileText, Mail } from "lucide-react";
import { toast } from "sonner";

export default function ExportTab() {
  const { data: doctors } = trpc.export.getDoctors.useQuery();
  const { data: dataShares } = trpc.export.getDataShares.useQuery();
  const { data: exportHistory } = trpc.export.getExportHistory.useQuery();

  const addDoctorMutation = trpc.export.addDoctor.useMutation();
  const shareMutation = trpc.export.shareWithDoctor.useMutation();
  const revokeMutation = trpc.export.revokeShare.useMutation();
  const generateReportMutation = trpc.export.generateHealthReport.useMutation();

  const [showDoctorForm, setShowDoctorForm] = useState(false);
  const [showShareForm, setShowShareForm] = useState(false);
  const [showExportOptions, setShowExportOptions] = useState(false);

  const [doctorForm, setDoctorForm] = useState({
    name: "",
    email: "",
    specialization: "",
    clinic: "",
    phone: "",
  });

  const [shareForm, setShareForm] = useState({
    doctorId: "",
    includeProfile: true,
    includeNotifications: true,
    includeReminders: true,
    expirationDays: 30,
  });

  const [exportOptions, setExportOptions] = useState({
    includeProfile: true,
    includeNotifications: true,
    includeReminders: true,
    exportFormat: "pdf" as const,
  });

  const handleAddDoctor = async () => {
    if (!doctorForm.name || !doctorForm.email) {
      toast.error("Please fill in name and email");
      return;
    }

    try {
      await addDoctorMutation.mutateAsync(doctorForm);
      toast.success("Doctor added successfully!");
      setDoctorForm({ name: "", email: "", specialization: "", clinic: "", phone: "" });
      setShowDoctorForm(false);
    } catch (error) {
      toast.error("Failed to add doctor");
    }
  };

  const handleShareData = async () => {
    if (!shareForm.doctorId) {
      toast.error("Please select a doctor");
      return;
    }

    try {
      const result = await shareMutation.mutateAsync({
        doctorId: parseInt(shareForm.doctorId),
        dataTypes: [
          shareForm.includeProfile && "profile",
          shareForm.includeNotifications && "notifications",
          shareForm.includeReminders && "reminders",
        ].filter(Boolean) as string[],
        expirationDays: shareForm.expirationDays,
      });

      toast.success("Data shared successfully!");
      setShareForm({
        doctorId: "",
        includeProfile: true,
        includeNotifications: true,
        includeReminders: true,
        expirationDays: 30,
      });
      setShowShareForm(false);
    } catch (error) {
      toast.error("Failed to share data");
    }
  };

  const handleGenerateReport = async () => {
    try {
      const result = await generateReportMutation.mutateAsync(exportOptions);
      toast.success("Report generated successfully!");
      // In a real app, this would trigger a download
      console.log("Report data:", result);
    } catch (error) {
      toast.error("Failed to generate report");
    }
  };

  const handleRevokeShare = async (shareId: number) => {
    try {
      await revokeMutation.mutateAsync({ shareId });
      toast.success("Share revoked successfully");
    } catch (error) {
      toast.error("Failed to revoke share");
    }
  };

  return (
    <div className="space-y-6">
      {/* Export Data Section */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Export Health Data</h2>
        <Card className="card-elevated p-6">
          <div className="space-y-4">
            <p className="text-muted-foreground">Download your complete health information in various formats</p>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="profile"
                  checked={exportOptions.includeProfile}
                  onChange={(e) => setExportOptions({ ...exportOptions, includeProfile: e.target.checked })}
                />
                <label htmlFor="profile" className="text-sm cursor-pointer">
                  Include Health Profile
                </label>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="notifications"
                  checked={exportOptions.includeNotifications}
                  onChange={(e) => setExportOptions({ ...exportOptions, includeNotifications: e.target.checked })}
                />
                <label htmlFor="notifications" className="text-sm cursor-pointer">
                  Include Health Notifications
                </label>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="reminders"
                  checked={exportOptions.includeReminders}
                  onChange={(e) => setExportOptions({ ...exportOptions, includeReminders: e.target.checked })}
                />
                <label htmlFor="reminders" className="text-sm cursor-pointer">
                  Include Reminders
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Export Format</label>
              <Select value={exportOptions.exportFormat} onValueChange={(value: any) => setExportOptions({ ...exportOptions, exportFormat: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF Report</SelectItem>
                  <SelectItem value="json">JSON Data</SelectItem>
                  <SelectItem value="csv">CSV Spreadsheet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={handleGenerateReport} disabled={generateReportMutation.isPending} className="btn-accent w-full">
              <Download className="w-4 h-4 mr-2" />
              Generate & Download Report
            </Button>
          </div>
        </Card>
      </div>

      {/* Doctor Management Section */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">My Doctors</h2>
          <Button onClick={() => setShowDoctorForm(!showDoctorForm)} className="btn-accent">
            <Plus className="w-4 h-4 mr-2" />
            Add Doctor
          </Button>
        </div>

        {showDoctorForm && (
          <Card className="card-elevated p-6 mb-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Doctor Name</label>
                <Input
                  placeholder="Dr. John Smith"
                  value={doctorForm.name}
                  onChange={(e) => setDoctorForm({ ...doctorForm, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <Input
                  type="email"
                  placeholder="doctor@clinic.com"
                  value={doctorForm.email}
                  onChange={(e) => setDoctorForm({ ...doctorForm, email: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Specialization</label>
                <Input
                  placeholder="e.g., Cardiologist"
                  value={doctorForm.specialization}
                  onChange={(e) => setDoctorForm({ ...doctorForm, specialization: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Clinic/Hospital</label>
                <Input
                  placeholder="Clinic name"
                  value={doctorForm.clinic}
                  onChange={(e) => setDoctorForm({ ...doctorForm, clinic: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Phone</label>
                <Input
                  placeholder="+1 (555) 123-4567"
                  value={doctorForm.phone}
                  onChange={(e) => setDoctorForm({ ...doctorForm, phone: e.target.value })}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddDoctor} disabled={addDoctorMutation.isPending} className="btn-accent">
                  Add Doctor
                </Button>
                <Button onClick={() => setShowDoctorForm(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {doctors && doctors.length > 0 ? (
          <div className="space-y-3">
            {doctors.map((doctor) => (
              <Card key={doctor.id} className="card-elevated p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold">{doctor.name}</h3>
                    <p className="text-sm text-muted-foreground">{doctor.email}</p>
                    {doctor.specialization && (
                      <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                    )}
                    {doctor.clinic && (
                      <p className="text-sm text-muted-foreground">{doctor.clinic}</p>
                    )}
                  </div>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="card-elevated p-8 text-center">
            <Mail className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">No doctors added yet. Add your healthcare providers to share data.</p>
          </Card>
        )}
      </div>

      {/* Data Sharing Section */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Shared Data</h2>
          <Button onClick={() => setShowShareForm(!showShareForm)} className="btn-accent">
            <Share2 className="w-4 h-4 mr-2" />
            Share Data
          </Button>
        </div>

        {showShareForm && doctors && doctors.length > 0 && (
          <Card className="card-elevated p-6 mb-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Select Doctor</label>
                <Select value={shareForm.doctorId} onValueChange={(value) => setShareForm({ ...shareForm, doctorId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a doctor" />
                  </SelectTrigger>
                  <SelectContent>
                    {doctors.map((doc) => (
                      <SelectItem key={doc.id} value={doc.id.toString()}>
                        {doc.name} - {doc.specialization || "General"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium">Data to Share</label>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="share-profile"
                    checked={shareForm.includeProfile}
                    onChange={(e) => setShareForm({ ...shareForm, includeProfile: e.target.checked })}
                  />
                  <label htmlFor="share-profile" className="text-sm cursor-pointer">
                    Health Profile
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="share-notifications"
                    checked={shareForm.includeNotifications}
                    onChange={(e) => setShareForm({ ...shareForm, includeNotifications: e.target.checked })}
                  />
                  <label htmlFor="share-notifications" className="text-sm cursor-pointer">
                    Health Notifications
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="share-reminders"
                    checked={shareForm.includeReminders}
                    onChange={(e) => setShareForm({ ...shareForm, includeReminders: e.target.checked })}
                  />
                  <label htmlFor="share-reminders" className="text-sm cursor-pointer">
                    Reminders
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Share Expiration (Days)</label>
                <Input
                  type="number"
                  min="1"
                  max="365"
                  value={shareForm.expirationDays}
                  onChange={(e) => setShareForm({ ...shareForm, expirationDays: parseInt(e.target.value) })}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleShareData} disabled={shareMutation.isPending} className="btn-accent">
                  Generate Share Link
                </Button>
                <Button onClick={() => setShowShareForm(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {dataShares && dataShares.length > 0 ? (
          <div className="space-y-3">
            {dataShares.map((share) => (
              <Card key={share.id} className="card-elevated p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold">Share ID: {share.id}</h3>
                    <p className="text-sm text-muted-foreground">Status: {share.status}</p>
                    <p className="text-sm text-muted-foreground">
                      Expires: {share.expiresAt ? new Date(share.expiresAt).toLocaleDateString() : "Never"}
                    </p>
                    <div className="mt-2 p-2 bg-muted rounded text-xs font-mono break-all">
                      {share.shareToken}
                    </div>
                  </div>
                  {share.status === "active" && (
                    <Button
                      onClick={() => handleRevokeShare(share.id)}
                      disabled={revokeMutation.isPending}
                      variant="ghost"
                      size="sm"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="card-elevated p-8 text-center">
            <Share2 className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">No active shares. Share your data with doctors to improve your care.</p>
          </Card>
        )}
      </div>

      {/* Export History Section */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Export History</h2>
        {exportHistory && exportHistory.length > 0 ? (
          <div className="space-y-3">
            {exportHistory.map((exp) => (
              <Card key={exp.id} className="card-elevated p-4">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-accent" />
                  <div>
                    <h3 className="font-semibold">{exp.fileName}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(exp.createdAt).toLocaleDateString()} - {exp.exportType.toUpperCase()}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="card-elevated p-8 text-center">
            <FileText className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">No exports yet. Generate your first health report above.</p>
          </Card>
        )}
      </div>
    </div>
  );
}
