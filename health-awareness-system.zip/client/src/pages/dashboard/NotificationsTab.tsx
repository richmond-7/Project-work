import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp, X, Bell } from "lucide-react";
import { healthTipsData } from "@shared/healthTips";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

export default function NotificationsTab() {
  const { data: notifications } = trpc.health.getNotifications.useQuery({ limit: 10 });
  const generateTipMutation = trpc.health.generateDailyTip.useMutation();
  const [expandedTip, setExpandedTip] = useState<string | null>(null);
  const [dismissedTips, setDismissedTips] = useState<Set<string>>(new Set());

  const handleToggleTip = (tipId: string) => {
    setExpandedTip(expandedTip === tipId ? null : tipId);
  };

  const handleDismissTip = (tipId: string) => {
    setDismissedTips((prev) => new Set(prev).add(tipId));
  };

  const handleGenerateTip = async () => {
    try {
      await generateTipMutation.mutateAsync();
      toast.success("Daily health tip generated!");
    } catch (error) {
      toast.error("Failed to generate tip");
    }
  };

  const visibleTips = healthTipsData.filter((tip) => !dismissedTips.has(tip.id));

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div>
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-2xl font-bold text-gradient">Key Health Areas</h2>
          <Button onClick={handleGenerateTip} disabled={generateTipMutation.isPending} className="btn-accent">
            Generate Daily Tip
          </Button>
        </div>
        <p className="text-muted-foreground">Click on any health area to explore tips and recommendations</p>
      </div>

      {/* Health Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence mode="popLayout">
          {visibleTips.map((tip) => (
            <motion.div
              key={tip.id}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3 }}
            >
              <Card
                className={`card-elevated overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 bg-gradient-to-br ${tip.color}`}
                onClick={() => handleToggleTip(tip.id)}
              >
                <div className="p-6 h-full flex flex-col">
                  {/* Card Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-4xl">{tip.icon}</div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDismissTip(tip.id);
                      }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Card Title and Description */}
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold mb-2">{tip.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{tip.description}</p>
                  </div>

                  {/* Expand Button */}
                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <span className="text-xs font-medium text-accent">
                      {expandedTip === tip.id ? "Show Less" : "Learn More"}
                    </span>
                    {expandedTip === tip.id ? (
                      <ChevronUp className="w-4 h-4 text-accent" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-accent" />
                    )}
                  </div>
                </div>
              </Card>

              {/* Expanded Details */}
              <AnimatePresence>
                {expandedTip === tip.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <Card className="card-elevated mt-2 p-6 bg-muted/50">
                      {/* Detailed Information */}
                      <div className="mb-6">
                        <h4 className="font-semibold mb-2 text-foreground">About {tip.title}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{tip.detailedInfo}</p>
                      </div>

                      {/* Quick Tips */}
                      <div className="mb-6">
                        <h4 className="font-semibold mb-3 text-foreground">Quick Tips</h4>
                        <ul className="space-y-2">
                          {tip.tips.map((tipText, index) => (
                            <li key={index} className="flex items-start gap-3">
                              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-accent/20 text-accent text-xs font-semibold flex-shrink-0 mt-0.5">
                                {index + 1}
                              </span>
                              <span className="text-sm text-muted-foreground">{tipText}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Recommendations */}
                      <div>
                        <h4 className="font-semibold mb-3 text-foreground">Recommendations</h4>
                        <ul className="space-y-2">
                          {tip.recommendations.map((rec, index) => (
                            <li key={index} className="flex items-start gap-3">
                              <span className="text-accent text-lg leading-none mt-0.5">✓</span>
                              <span className="text-sm text-muted-foreground">{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2 mt-6">
                        <Button className="btn-accent flex-1" size="sm">
                          Set Reminder
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          Save for Later
                        </Button>
                      </div>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Recent Notifications */}
      {notifications && notifications.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4">Recent Notifications</h3>
          <div className="space-y-3">
            {notifications.slice(0, 5).map((notif) => (
              <Card key={notif.id} className="card-elevated p-4">
                <div className="flex items-start gap-3">
                  <Bell className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-medium text-sm">{notif.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{notif.content}</p>
                    <div className="flex gap-2 mt-2">
                      {notif.category && (
                        <span className="inline-block px-2 py-1 bg-accent/10 text-accent text-xs rounded">
                          {notif.category}
                        </span>
                      )}
                      {notif.diseaseType && (
                        <span className="inline-block px-2 py-1 bg-secondary/10 text-secondary text-xs rounded">
                          {notif.diseaseType}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground/70 mt-2">
                      {new Date(notif.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {visibleTips.length === 0 && (
        <Card className="card-elevated p-12 text-center">
          <div className="text-4xl mb-4">📚</div>
          <p className="text-muted-foreground mb-4">All health tips dismissed</p>
          <Button onClick={() => setDismissedTips(new Set())} className="btn-accent">
            Reset All Tips
          </Button>
        </Card>
      )}
    </div>
  );
}
