import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Settings, Save } from "lucide-react";
import { toast } from "sonner";

export default function ProfileTab() {
  const { data: profile, isLoading } = trpc.health.getProfile.useQuery();
  const updateProfileMutation = trpc.health.updateProfile.useMutation();
  const [formData, setFormData] = useState({
    age: "",
    chronicDiseases: [] as string[],
    allergies: [] as string[],
    medications: [] as string[],
    emergencyContact: "",
    emergencyContactPhone: "",
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        age: profile.age?.toString() || "",
        chronicDiseases: profile.chronicDiseases ? JSON.parse(profile.chronicDiseases) : [],
        allergies: profile.allergies ? JSON.parse(profile.allergies) : [],
        medications: profile.medications ? JSON.parse(profile.medications) : [],
        emergencyContact: profile.emergencyContact || "",
        emergencyContactPhone: profile.emergencyContactPhone || "",
      });
    }
  }, [profile]);

  const handleAddItem = (field: "chronicDiseases" | "allergies" | "medications", value: string) => {
    if (value.trim()) {
      setFormData((prev) => ({
        ...prev,
        [field]: [...prev[field], value],
      }));
    }
  };

  const handleRemoveItem = (field: "chronicDiseases" | "allergies" | "medications", index: number) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index),
    }));
  };

  const handleSaveProfile = async () => {
    try {
      await updateProfileMutation.mutateAsync({
        age: formData.age ? parseInt(formData.age) : undefined,
        chronicDiseases: formData.chronicDiseases,
        allergies: formData.allergies,
        medications: formData.medications,
        emergencyContact: formData.emergencyContact,
        emergencyContactPhone: formData.emergencyContactPhone,
      });
      toast.success("Profile updated successfully!");
    } catch (error) {
      toast.error("Failed to update profile");
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading profile...</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold flex items-center gap-2">
        <Settings className="w-5 h-5" />
        Health Profile
      </h2>

      <Card className="card-elevated p-6">
        <div className="space-y-6">
          {/* Basic Info */}
          <div>
            <h3 className="font-semibold mb-4">Basic Information</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">Age</label>
                <Input
                  type="number"
                  placeholder="Your age"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                />
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div>
            <h3 className="font-semibold mb-4">Emergency Contact</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">Contact Name</label>
                <Input
                  placeholder="Emergency contact name"
                  value={formData.emergencyContact}
                  onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Contact Phone</label>
                <Input
                  placeholder="Emergency contact phone"
                  value={formData.emergencyContactPhone}
                  onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                />
              </div>
            </div>
          </div>

          {/* Chronic Diseases */}
          <div>
            <h3 className="font-semibold mb-4">Chronic Diseases</h3>
            <div className="space-y-2">
              {formData.chronicDiseases.map((disease, idx) => (
                <div key={idx} className="flex items-center justify-between bg-muted p-2 rounded">
                  <span>{disease}</span>
                  <button
                    onClick={() => handleRemoveItem("chronicDiseases", idx)}
                    className="text-destructive hover:text-destructive/80"
                  >
                    ×
                  </button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input
                  placeholder="Add disease (e.g., diabetes, hypertension)"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleAddItem("chronicDiseases", (e.target as HTMLInputElement).value);
                      (e.target as HTMLInputElement).value = "";
                    }
                  }}
                />
              </div>
            </div>
          </div>

          {/* Allergies */}
          <div>
            <h3 className="font-semibold mb-4">Allergies</h3>
            <div className="space-y-2">
              {formData.allergies.map((allergy, idx) => (
                <div key={idx} className="flex items-center justify-between bg-muted p-2 rounded">
                  <span>{allergy}</span>
                  <button
                    onClick={() => handleRemoveItem("allergies", idx)}
                    className="text-destructive hover:text-destructive/80"
                  >
                    ×
                  </button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input
                  placeholder="Add allergy"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleAddItem("allergies", (e.target as HTMLInputElement).value);
                      (e.target as HTMLInputElement).value = "";
                    }
                  }}
                />
              </div>
            </div>
          </div>

          {/* Medications */}
          <div>
            <h3 className="font-semibold mb-4">Current Medications</h3>
            <div className="space-y-2">
              {formData.medications.map((med, idx) => (
                <div key={idx} className="flex items-center justify-between bg-muted p-2 rounded">
                  <span>{med}</span>
                  <button
                    onClick={() => handleRemoveItem("medications", idx)}
                    className="text-destructive hover:text-destructive/80"
                  >
                    ×
                  </button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input
                  placeholder="Add medication"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleAddItem("medications", (e.target as HTMLInputElement).value);
                      (e.target as HTMLInputElement).value = "";
                    }
                  }}
                />
              </div>
            </div>
          </div>

          <Button onClick={handleSaveProfile} disabled={updateProfileMutation.isPending} className="btn-accent w-full">
            <Save className="w-4 h-4 mr-2" />
            Save Profile
          </Button>
        </div>
      </Card>
    </div>
  );
}
