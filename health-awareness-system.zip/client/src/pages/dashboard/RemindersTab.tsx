import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function RemindersTab() {
  const { data: reminders, isLoading } = trpc.health.getReminders.useQuery();
  const createReminderMutation = trpc.health.createReminder.useMutation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    type: "medication" as const,
    title: "",
    description: "",
    scheduledTime: "",
    frequency: "once" as const,
  });

  const handleCreateReminder = async () => {
    if (!formData.title || !formData.scheduledTime) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await createReminderMutation.mutateAsync({
        ...formData,
        scheduledTime: new Date(formData.scheduledTime),
      });
      toast.success("Reminder created successfully!");
      setFormData({ type: "medication", title: "", description: "", scheduledTime: "", frequency: "once" });
      setShowForm(false);
    } catch (error) {
      toast.error("Failed to create reminder");
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading reminders...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Medication & Appointments</h2>
        <Button onClick={() => setShowForm(!showForm)} className="btn-accent">
          <Plus className="w-4 h-4 mr-2" />
          New Reminder
        </Button>
      </div>

      {showForm && (
        <Card className="card-elevated p-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Type</label>
              <Select value={formData.type} onValueChange={(value: any) => setFormData({ ...formData, type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medication">Medication</SelectItem>
                  <SelectItem value="appointment">Appointment</SelectItem>
                  <SelectItem value="checkup">Checkup</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <Input
                placeholder="e.g., Take blood pressure medication"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <Input
                placeholder="Additional notes"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Scheduled Time</label>
              <Input
                type="datetime-local"
                value={formData.scheduledTime}
                onChange={(e) => setFormData({ ...formData, scheduledTime: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Frequency</label>
              <Select value={formData.frequency} onValueChange={(value: any) => setFormData({ ...formData, frequency: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="once">Once</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateReminder} disabled={createReminderMutation.isPending} className="btn-accent">
                Create Reminder
              </Button>
              <Button onClick={() => setShowForm(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      {reminders && reminders.length > 0 ? (
        <div className="space-y-3">
          {reminders.map((reminder) => (
            <Card key={reminder.id} className="card-elevated p-4">
              <div className="flex gap-4">
                <Clock className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold">{reminder.title}</h3>
                      {reminder.description && (
                        <p className="text-sm text-muted-foreground mt-1">{reminder.description}</p>
                      )}
                      <div className="flex gap-2 mt-2">
                        <span className="inline-block px-2 py-1 bg-accent/10 text-accent text-xs rounded capitalize">
                          {reminder.type}
                        </span>
                        <span className="inline-block px-2 py-1 bg-secondary/10 text-secondary text-xs rounded capitalize">
                          {reminder.frequency}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(reminder.scheduledTime).toLocaleString()}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-elevated p-8 text-center">
          <Clock className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No reminders yet. Create one to stay on track with your health!</p>
        </Card>
      )}
    </div>
  );
}
