import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User health profile with chronic disease information
 */
export const healthProfiles = mysqlTable("health_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  age: int("age"),
  chronicDiseases: text("chronicDiseases"), // JSON array of disease types
  allergies: text("allergies"), // JSON array
  medications: text("medications"), // JSON array
  emergencyContact: varchar("emergencyContact", { length: 320 }),
  emergencyContactPhone: varchar("emergencyContactPhone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HealthProfile = typeof healthProfiles.$inferSelect;
export type InsertHealthProfile = typeof healthProfiles.$inferInsert;

/**
 * Daily health notifications/tips
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  category: varchar("category", { length: 50 }), // e.g., "medication", "exercise", "diet"
  diseaseType: varchar("diseaseType", { length: 100 }), // specific disease this tip is for
  isRead: int("isRead").default(0).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Medication and appointment reminders
 */
export const reminders = mysqlTable("reminders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: mysqlEnum("type", ["medication", "appointment", "checkup"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  scheduledTime: timestamp("scheduledTime").notNull(),
  frequency: varchar("frequency", { length: 50 }), // "once", "daily", "weekly", "monthly"
  isActive: int("isActive").default(1).notNull(),
  lastNotifiedAt: timestamp("lastNotifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Reminder = typeof reminders.$inferSelect;
export type InsertReminder = typeof reminders.$inferInsert;

/**
 * Chatbot conversation logs
 */
export const chatbotLogs = mysqlTable("chatbot_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  conversationId: varchar("conversationId", { length: 100 }).notNull(),
  userMessage: text("userMessage").notNull(),
  botResponse: text("botResponse").notNull(),
  escalated: int("escalated").default(0).notNull(),
  escalatedTo: varchar("escalatedTo", { length: 100 }), // email or ID of human operator
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatbotLog = typeof chatbotLogs.$inferSelect;
export type InsertChatbotLog = typeof chatbotLogs.$inferInsert;

/**
 * Emergency alerts
 */
export const emergencyAlerts = mysqlTable("emergency_alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 255 }),
  status: mysqlEnum("status", ["pending", "acknowledged", "resolved"]).default("pending").notNull(),
  respondedBy: varchar("respondedBy", { length: 100 }),
  respondedAt: timestamp("respondedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmergencyAlert = typeof emergencyAlerts.$inferSelect;
export type InsertEmergencyAlert = typeof emergencyAlerts.$inferInsert;

/**
 * Community discussion posts
 */
export const communityPosts = mysqlTable("community_posts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  category: varchar("category", { length: 100 }), // e.g., "tips", "experiences", "questions"
  likes: int("likes").default(0).notNull(),
  replies: int("replies").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = typeof communityPosts.$inferInsert;

/**
 * Community post replies/comments
 */
export const communityReplies = mysqlTable("community_replies", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull().references(() => communityPosts.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  likes: int("likes").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityReply = typeof communityReplies.$inferSelect;
export type InsertCommunityReply = typeof communityReplies.$inferInsert;

/**
 * Doctor/Healthcare provider management
 */
export const doctors = mysqlTable("doctors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  specialization: varchar("specialization", { length: 100 }),
  clinic: varchar("clinic", { length: 255 }),
  phone: varchar("phone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = typeof doctors.$inferInsert;

/**
 * Data sharing records for tracking doctor access
 */
export const dataSharing = mysqlTable("data_sharing", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  doctorId: int("doctorId").notNull().references(() => doctors.id, { onDelete: "cascade" }),
  shareToken: varchar("shareToken", { length: 100 }).notNull().unique(),
  expiresAt: timestamp("expiresAt"),
  accessedAt: timestamp("accessedAt"),
  dataTypes: varchar("dataTypes", { length: 255 }), // JSON array: profile, notifications, reminders, etc
  status: mysqlEnum("status", ["active", "revoked", "expired"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DataSharing = typeof dataSharing.$inferSelect;
export type InsertDataSharing = typeof dataSharing.$inferInsert;

/**
 * Health data exports (PDF records)
 */
export const healthExports = mysqlTable("health_exports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  exportType: mysqlEnum("exportType", ["pdf", "json", "csv"]).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileUrl: text("fileUrl"),
  dataIncluded: varchar("dataIncluded", { length: 255 }), // JSON array of included data types
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type HealthExport = typeof healthExports.$inferSelect;
export type InsertHealthExport = typeof healthExports.$inferInsert;