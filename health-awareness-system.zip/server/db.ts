import { eq, desc, asc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, healthProfiles, InsertHealthProfile, notifications, InsertNotification, reminders, InsertReminder, chatbotLogs, InsertChatbotLog, emergencyAlerts, InsertEmergencyAlert, communityPosts, InsertCommunityPost, communityReplies, InsertCommunityReply, doctors, InsertDoctor, dataSharing, InsertDataSharing, healthExports, InsertHealthExport } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getHealthProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(healthProfiles).where(eq(healthProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateHealthProfile(userId: number, data: Partial<InsertHealthProfile>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getHealthProfile(userId);
  if (existing) {
    await db.update(healthProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(healthProfiles.userId, userId));
  } else {
    await db.insert(healthProfiles).values({ userId, ...data });
  }
}

export async function getUserNotifications(userId: number, limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(notifications).values(data);
}

export async function getUserReminders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reminders)
    .where(eq(reminders.userId, userId))
    .orderBy(asc(reminders.scheduledTime));
}

export async function createReminder(data: InsertReminder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(reminders).values(data);
}

export async function updateReminder(reminderId: number, data: Partial<InsertReminder>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(reminders).set(data).where(eq(reminders.id, reminderId));
}

export async function getChatbotLogs(userId: number, conversationId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatbotLogs)
    .where(and(eq(chatbotLogs.userId, userId), eq(chatbotLogs.conversationId, conversationId)))
    .orderBy(asc(chatbotLogs.createdAt));
}

export async function createChatbotLog(data: InsertChatbotLog) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(chatbotLogs).values(data);
}

export async function createEmergencyAlert(data: InsertEmergencyAlert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(emergencyAlerts).values(data);
}

export async function getUserEmergencyAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emergencyAlerts)
    .where(eq(emergencyAlerts.userId, userId))
    .orderBy(desc(emergencyAlerts.createdAt));
}

export async function getCommunityPosts(limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityPosts)
    .orderBy(desc(communityPosts.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function createCommunityPost(data: InsertCommunityPost) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(communityPosts).values(data);
  return result;
}

export async function getCommunityPostReplies(postId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityReplies)
    .where(eq(communityReplies.postId, postId))
    .orderBy(asc(communityReplies.createdAt));
}

export async function createCommunityReply(data: InsertCommunityReply) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(communityReplies).values(data);
}

// Doctor Management
export async function getUserDoctors(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(doctors)
    .where(eq(doctors.userId, userId))
    .orderBy(desc(doctors.createdAt));
}

export async function addDoctor(data: InsertDoctor) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(doctors).values(data);
  return result;
}

export async function removeDoctor(doctorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(doctors).where(eq(doctors.id, doctorId));
}

// Data Sharing
export async function createDataSharing(data: InsertDataSharing) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(dataSharing).values(data);
}

export async function getDataSharingByToken(shareToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(dataSharing)
    .where(eq(dataSharing.shareToken, shareToken))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserDataShares(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dataSharing)
    .where(eq(dataSharing.userId, userId))
    .orderBy(desc(dataSharing.createdAt));
}

export async function revokeDataSharing(sharerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(dataSharing)
    .set({ status: "revoked" })
    .where(eq(dataSharing.id, sharerId));
}

// Health Exports
export async function createHealthExport(data: InsertHealthExport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(healthExports).values(data);
}

export async function getUserHealthExports(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(healthExports)
    .where(eq(healthExports.userId, userId))
    .orderBy(desc(healthExports.createdAt));
}
