import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getCommunityPosts,
  createCommunityPost,
  getCommunityPostReplies,
  createCommunityReply,
} from "../db";

export const communityRouter = router({
  // Get all community posts with pagination
  getPosts: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      return getCommunityPosts(input.limit, input.offset);
    }),

  // Create a new community post
  createPost: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        content: z.string().min(1),
        category: z.enum(["tips", "experiences", "questions", "support"]).default("experiences"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createCommunityPost({
        userId: ctx.user.id,
        title: input.title,
        content: input.content,
        category: input.category,
      });
      return { success: true };
    }),

  // Get replies for a specific post
  getPostReplies: protectedProcedure
    .input(z.object({ postId: z.number() }))
    .query(async ({ input }) => {
      return getCommunityPostReplies(input.postId);
    }),

  // Create a reply to a post
  createReply: protectedProcedure
    .input(
      z.object({
        postId: z.number(),
        content: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createCommunityReply({
        postId: input.postId,
        userId: ctx.user.id,
        content: input.content,
      });
      return { success: true };
    }),
});
