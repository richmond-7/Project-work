import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getUserDoctors,
  addDoctor,
  removeDoctor,
  createDataSharing,
  getUserDataShares,
  revokeDataSharing,
  createHealthExport,
  getUserHealthExports,
  getHealthProfile,
  getUserNotifications,
  getUserReminders,
  getDataSharingByToken,
} from "../db";
import { nanoid } from "nanoid";

export const exportRouter = router({
  // Doctor Management
  getDoctors: protectedProcedure.query(async ({ ctx }) => {
    return getUserDoctors(ctx.user.id);
  }),

  addDoctor: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        specialization: z.string().optional(),
        clinic: z.string().optional(),
        phone: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await addDoctor({
        userId: ctx.user.id,
        ...input,
      });
      return { success: true };
    }),

  removeDoctor: protectedProcedure
    .input(z.object({ doctorId: z.number() }))
    .mutation(async ({ input }) => {
      await removeDoctor(input.doctorId);
      return { success: true };
    }),

  // Data Sharing
  shareWithDoctor: protectedProcedure
    .input(
      z.object({
        doctorId: z.number(),
        dataTypes: z.array(z.string()).default(["profile", "notifications", "reminders"]),
        expirationDays: z.number().default(30),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const shareToken = nanoid(32);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + input.expirationDays);

      await createDataSharing({
        userId: ctx.user.id,
        doctorId: input.doctorId,
        shareToken,
        expiresAt,
        dataTypes: JSON.stringify(input.dataTypes),
      });

      return {
        success: true,
        shareToken,
        expiresAt,
      };
    }),

  getDataShares: protectedProcedure.query(async ({ ctx }) => {
    return getUserDataShares(ctx.user.id);
  }),

  revokeShare: protectedProcedure
    .input(z.object({ shareId: z.number() }))
    .mutation(async ({ input }) => {
      await revokeDataSharing(input.shareId);
      return { success: true };
    }),

  // Health Data Export
  getExportHistory: protectedProcedure.query(async ({ ctx }) => {
    return getUserHealthExports(ctx.user.id);
  }),

  generateHealthReport: protectedProcedure
    .input(
      z.object({
        includeProfile: z.boolean().default(true),
        includeNotifications: z.boolean().default(true),
        includeReminders: z.boolean().default(true),
        exportFormat: z.enum(["pdf", "json", "csv"]).default("pdf"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Gather health data
      const profile = await getHealthProfile(ctx.user.id);
      const notifications = input.includeNotifications ? await getUserNotifications(ctx.user.id, 50) : [];
      const reminders = input.includeReminders ? await getUserReminders(ctx.user.id) : [];

      const healthData = {
        user: {
          id: ctx.user.id,
          name: ctx.user.name,
          email: ctx.user.email,
          exportedAt: new Date().toISOString(),
        },
        profile: input.includeProfile ? profile : null,
        notifications: notifications,
        reminders: reminders,
      };

      // Create export record
      const fileName = `health_report_${ctx.user.id}_${Date.now()}.${input.exportFormat}`;
      const dataIncluded = JSON.stringify({
        profile: input.includeProfile,
        notifications: input.includeNotifications,
        reminders: input.includeReminders,
      });

      await createHealthExport({
        userId: ctx.user.id,
        exportType: input.exportFormat,
        fileName,
        dataIncluded,
      });

      return {
        success: true,
        fileName,
        data: healthData,
        format: input.exportFormat,
      };
    }),

  // Access shared data (for doctors/recipients)
  accessSharedData: protectedProcedure
    .input(z.object({ shareToken: z.string() }))
    .query(async ({ input }) => {
      const share = await getDataSharingByToken(input.shareToken);

      if (!share) {
        throw new Error("Invalid or expired share token");
      }

      if (share.status !== "active") {
        throw new Error("This share has been revoked or expired");
      }

      if (share.expiresAt && new Date() > share.expiresAt) {
        throw new Error("This share has expired");
      }

      // Get the shared data based on dataTypes
      const dataTypes = JSON.parse(share.dataTypes || "[]");
      const sharedData: any = {
        shareInfo: {
          sharedAt: share.createdAt,
          expiresAt: share.expiresAt,
        },
      };

      if (dataTypes.includes("profile")) {
        sharedData.profile = await getHealthProfile(share.userId);
      }

      if (dataTypes.includes("notifications")) {
        sharedData.notifications = await getUserNotifications(share.userId, 20);
      }

      if (dataTypes.includes("reminders")) {
        sharedData.reminders = await getUserReminders(share.userId);
      }

      return {
        success: true,
        data: sharedData,
      };
    }),
});
