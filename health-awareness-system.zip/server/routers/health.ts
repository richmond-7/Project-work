import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getHealthProfile,
  createOrUpdateHealthProfile,
  getUserNotifications,
  createNotification,
  getUserReminders,
  createReminder,
  updateReminder,
  getChatbotLogs,
  createChatbotLog,
  createEmergencyAlert,
  getUserEmergencyAlerts,
} from "../db";

const HEALTH_TIPS = {
  diabetes: [
    { title: "Monitor Blood Sugar", content: "Check your blood sugar levels regularly as recommended by your doctor." },
    { title: "Healthy Eating", content: "Focus on whole grains, vegetables, and lean proteins. Limit sugary foods." },
    { title: "Stay Active", content: "Aim for at least 150 minutes of moderate exercise per week." },
  ],
  hypertension: [
    { title: "Reduce Salt Intake", content: "Limit sodium to less than 2,300mg per day." },
    { title: "Manage Stress", content: "Practice relaxation techniques like meditation or yoga." },
    { title: "Regular Checkups", content: "Monitor your blood pressure regularly." },
  ],
  asthma: [
    { title: "Use Inhaler Correctly", content: "Follow your doctor's instructions for proper inhaler use." },
    { title: "Avoid Triggers", content: "Identify and avoid your personal asthma triggers." },
    { title: "Keep Medications Ready", content: "Always carry your rescue inhaler with you." },
  ],
  general: [
    { title: "Drink Water", content: "Stay hydrated by drinking at least 8 glasses of water daily." },
    { title: "Get Sleep", content: "Aim for 7-9 hours of quality sleep each night." },
    { title: "Exercise Regularly", content: "Include both cardio and strength training in your routine." },
  ],
};

export const healthRouter = router({
  // Health Profile Management
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    return getHealthProfile(ctx.user.id);
  }),

  updateProfile: protectedProcedure
    .input(
      z.object({
        age: z.number().min(0).max(150).optional(),
        chronicDiseases: z.array(z.string()).optional(),
        allergies: z.array(z.string()).optional(),
        medications: z.array(z.string()).optional(),
        emergencyContact: z.string().optional(),
        emergencyContactPhone: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createOrUpdateHealthProfile(ctx.user.id, {
        age: input.age,
        chronicDiseases: input.chronicDiseases ? JSON.stringify(input.chronicDiseases) : undefined,
        allergies: input.allergies ? JSON.stringify(input.allergies) : undefined,
        medications: input.medications ? JSON.stringify(input.medications) : undefined,
        emergencyContact: input.emergencyContact,
        emergencyContactPhone: input.emergencyContactPhone,
      });
      return { success: true };
    }),

  // Notifications
  getNotifications: protectedProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ ctx, input }) => {
      return getUserNotifications(ctx.user.id, input.limit);
    }),

  generateDailyTip: protectedProcedure.mutation(async ({ ctx }) => {
    const profile = await getHealthProfile(ctx.user.id);
    const diseases = profile?.chronicDiseases ? JSON.parse(profile.chronicDiseases) : [];
    const diseaseType = diseases.length > 0 ? diseases[0] : "general";
    const tips = HEALTH_TIPS[diseaseType as keyof typeof HEALTH_TIPS] || HEALTH_TIPS.general;
    const tip = tips[Math.floor(Math.random() * tips.length)];

    await createNotification({
      userId: ctx.user.id,
      title: tip.title,
      content: tip.content,
      category: "health_tip",
      diseaseType: diseaseType,
    });

    return { success: true, tip };
  }),

  // Reminders
  getReminders: protectedProcedure.query(async ({ ctx }) => {
    return getUserReminders(ctx.user.id);
  }),

  createReminder: protectedProcedure
    .input(
      z.object({
        type: z.enum(["medication", "appointment", "checkup"]),
        title: z.string().min(1),
        description: z.string().optional(),
        scheduledTime: z.date(),
        frequency: z.enum(["once", "daily", "weekly", "monthly"]).default("once"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createReminder({
        userId: ctx.user.id,
        type: input.type,
        title: input.title,
        description: input.description,
        scheduledTime: input.scheduledTime,
        frequency: input.frequency,
      });
      return { success: true };
    }),

  updateReminder: protectedProcedure
    .input(
      z.object({
        reminderId: z.number(),
        isActive: z.boolean().optional(),
        scheduledTime: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await updateReminder(input.reminderId, {
        isActive: input.isActive ? 1 : 0,
        scheduledTime: input.scheduledTime,
      });
      return { success: true };
    }),

  // Chatbot
  getChatHistory: protectedProcedure
    .input(z.object({ conversationId: z.string() }))
    .query(async ({ ctx, input }) => {
      return getChatbotLogs(ctx.user.id, input.conversationId);
    }),

  sendChatMessage: protectedProcedure
    .input(
      z.object({
        conversationId: z.string(),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Simple chatbot responses based on keywords
      const lowerMessage = input.message.toLowerCase();
      let botResponse = "I'm here to help. Could you provide more details about your health concern?";

      if (lowerMessage.includes("medication")) {
        botResponse = "For medication questions, please consult your healthcare provider. I can help you set reminders for your medications.";
      } else if (lowerMessage.includes("appointment")) {
        botResponse = "I can help you schedule appointment reminders. Would you like to create one?";
      } else if (lowerMessage.includes("emergency")) {
        botResponse = "If this is a medical emergency, please call emergency services immediately or use our emergency alert feature.";
      } else if (lowerMessage.includes("diet") || lowerMessage.includes("food")) {
        botResponse = "For personalized diet advice, consult a nutritionist. I can provide general healthy eating tips based on your health profile.";
      } else if (lowerMessage.includes("exercise") || lowerMessage.includes("workout")) {
        botResponse = "Regular exercise is beneficial for most health conditions. Aim for at least 150 minutes of moderate activity per week.";
      }

      await createChatbotLog({
        userId: ctx.user.id,
        conversationId: input.conversationId,
        userMessage: input.message,
        botResponse: botResponse,
      });

      return { response: botResponse };
    }),

  escalateChat: protectedProcedure
    .input(
      z.object({
        conversationId: z.string(),
        reason: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // In a real system, this would notify a human operator
      await createChatbotLog({
        userId: ctx.user.id,
        conversationId: input.conversationId,
        userMessage: `[ESCALATION REQUEST: ${input.reason}]`,
        botResponse: "Your request has been escalated to a human operator. They will assist you shortly.",
        escalated: 1,
        escalatedTo: "support@healthawareness.com",
      });
      return { success: true };
    }),

  // Emergency Alerts
  createEmergencyAlert: protectedProcedure
    .input(
      z.object({
        severity: z.enum(["low", "medium", "high", "critical"]),
        description: z.string().min(1),
        location: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await createEmergencyAlert({
        userId: ctx.user.id,
        severity: input.severity,
        description: input.description,
        location: input.location,
      });
      // In a real system, this would send notifications to nearby health volunteers/clinics
      return { success: true };
    }),

  getEmergencyAlerts: protectedProcedure.query(async ({ ctx }) => {
    return getUserEmergencyAlerts(ctx.user.id);
  }),
});
