export interface HealthTip {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  tips: string[];
  detailedInfo: string;
  recommendations: string[];
}

export const healthTipsData: HealthTip[] = [
  {
    id: "heart-health",
    title: "Heart Health",
    description: "Maintain cardiovascular wellness and prevent heart disease",
    icon: "❤️",
    color: "from-red-500/10 to-rose-500/10",
    tips: [
      "Exercise regularly for at least 30 minutes daily",
      "Maintain a healthy diet low in saturated fats",
      "Monitor your blood pressure regularly",
      "Reduce salt intake to less than 5g per day",
      "Manage stress through meditation or yoga",
    ],
    detailedInfo:
      "Heart health is crucial for overall wellness. Regular cardiovascular exercise strengthens your heart muscle, improves circulation, and helps maintain healthy blood pressure and cholesterol levels. A balanced diet rich in fruits, vegetables, and whole grains supports heart function.",
    recommendations: [
      "Aim for 150 minutes of moderate aerobic activity per week",
      "Include heart-healthy foods like salmon, nuts, and olive oil",
      "Get your blood pressure checked annually",
      "Quit smoking if applicable",
      "Limit alcohol consumption",
    ],
  },
  {
    id: "mental-health",
    title: "Mental Health",
    description: "Support emotional well-being and mental resilience",
    icon: "🧠",
    color: "from-purple-500/10 to-indigo-500/10",
    tips: [
      "Practice mindfulness and meditation daily",
      "Maintain social connections and relationships",
      "Get adequate sleep (7-9 hours per night)",
      "Engage in activities you enjoy",
      "Seek professional help when needed",
    ],
    detailedInfo:
      "Mental health is as important as physical health. Stress management, quality sleep, and social connections are essential for emotional well-being. Regular mindfulness practices can reduce anxiety and improve overall mental resilience.",
    recommendations: [
      "Practice 10-15 minutes of meditation daily",
      "Maintain regular sleep schedule",
      "Connect with friends and family weekly",
      "Engage in hobbies and creative activities",
      "Consider therapy or counseling if struggling",
    ],
  },
  {
    id: "respiratory-health",
    title: "Respiratory Health",
    description: "Protect and strengthen your lungs and breathing",
    icon: "💨",
    color: "from-blue-500/10 to-cyan-500/10",
    tips: [
      "Avoid smoking and secondhand smoke",
      "Exercise to improve lung capacity",
      "Practice deep breathing exercises",
      "Maintain good air quality at home",
      "Get vaccinated against respiratory infections",
    ],
    detailedInfo:
      "Healthy lungs are vital for oxygen delivery throughout your body. Avoiding pollutants, regular exercise, and breathing techniques can significantly improve respiratory function and prevent chronic diseases.",
    recommendations: [
      "Avoid air pollution and smoke exposure",
      "Do cardio exercises 3-4 times per week",
      "Practice deep breathing for 5 minutes daily",
      "Use air purifiers if needed",
      "Get annual flu vaccination",
    ],
  },
  {
    id: "physical-activity",
    title: "Physical Activity",
    description: "Stay active and maintain physical fitness",
    icon: "🏃",
    color: "from-green-500/10 to-emerald-500/10",
    tips: [
      "Aim for 150 minutes of moderate exercise weekly",
      "Include strength training 2-3 times per week",
      "Stay active throughout the day",
      "Find activities you enjoy",
      "Gradually increase intensity over time",
    ],
    detailedInfo:
      "Regular physical activity improves cardiovascular health, strengthens muscles and bones, enhances mental well-being, and helps maintain a healthy weight. A mix of aerobic exercise and strength training provides comprehensive fitness benefits.",
    recommendations: [
      "Start with 20-30 minute walks daily",
      "Add weight training 2 days per week",
      "Take breaks from sitting every hour",
      "Join group fitness classes for motivation",
      "Track your activity with a fitness app",
    ],
  },
  {
    id: "nutrition",
    title: "Nutrition",
    description: "Fuel your body with balanced and healthy eating",
    icon: "🥗",
    color: "from-orange-500/10 to-amber-500/10",
    tips: [
      "Eat a variety of colorful fruits and vegetables",
      "Choose whole grains over refined carbs",
      "Include lean proteins in every meal",
      "Stay hydrated with plenty of water",
      "Limit processed foods and added sugars",
    ],
    detailedInfo:
      "Proper nutrition provides essential nutrients for energy, growth, and disease prevention. A balanced diet includes fruits, vegetables, whole grains, lean proteins, and healthy fats. Staying hydrated and limiting processed foods supports optimal health.",
    recommendations: [
      "Fill half your plate with vegetables",
      "Choose whole grain bread and pasta",
      "Include fish 2-3 times per week",
      "Drink at least 8 glasses of water daily",
      "Plan meals ahead to avoid unhealthy choices",
    ],
  },
  {
    id: "sleep-health",
    title: "Sleep Health",
    description: "Achieve quality rest and better sleep patterns",
    icon: "😴",
    color: "from-indigo-500/10 to-blue-500/10",
    tips: [
      "Maintain a consistent sleep schedule",
      "Create a dark, cool, quiet bedroom",
      "Avoid screens 1 hour before bed",
      "Limit caffeine after 2 PM",
      "Practice relaxation techniques before sleep",
    ],
    detailedInfo:
      "Quality sleep is essential for physical recovery, mental health, and immune function. During sleep, your body repairs tissues, consolidates memories, and regulates hormones. Poor sleep increases risk of chronic diseases.",
    recommendations: [
      "Go to bed and wake up at the same time daily",
      "Keep bedroom temperature between 60-67°F",
      "Use blackout curtains and white noise if needed",
      "Avoid alcohol and heavy meals before bed",
      "Try meditation or progressive muscle relaxation",
    ],
  },
];

export const getHealthTipById = (id: string): HealthTip | undefined => {
  return healthTipsData.find((tip) => tip.id === id);
};

export const getAllHealthTips = (): HealthTip[] => {
  return healthTipsData;
};
